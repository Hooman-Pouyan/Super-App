import { CarouselDemo } from "@/shared/components/carousel";

export default function Discounts() {
  return (
    <>
      {/* <CarouselDemo classNames="basis-2/3" /> */}
    </>
  );
}
