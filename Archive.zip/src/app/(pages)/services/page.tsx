import { CarouselDemo } from "@/shared/components/carousel";
import Image from "next/image";

export default function Service() {
  return <></>;
}
